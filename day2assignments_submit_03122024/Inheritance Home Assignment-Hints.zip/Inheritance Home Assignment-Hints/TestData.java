package week3.day2assignments_03122024;

public class TestData {
	 public void enterCredentials() {
		System.out.println("Enter TestData Credentials");

	}
	 public void navigateToHomePage() {
		 System.out.println("Navigation to Home Page");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
