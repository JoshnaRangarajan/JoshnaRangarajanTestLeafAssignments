package week3.day2assignments_03122024;

public class TextField extends WebElement{
	public void getText() {
		System.out.println("To get the text from API");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
