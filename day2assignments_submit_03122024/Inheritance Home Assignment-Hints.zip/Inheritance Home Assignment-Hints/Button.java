package week3.day2assignments_03122024;

public class Button extends WebElement {
	public void submit() {
		System.out.println("Project is submitted");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
