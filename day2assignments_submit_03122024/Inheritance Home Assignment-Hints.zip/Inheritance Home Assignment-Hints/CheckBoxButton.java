package week3.day2assignments_03122024;

public class CheckBoxButton extends Button{
	public void clickCheckButton() {
		System.out.println("Click on Check Button");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
