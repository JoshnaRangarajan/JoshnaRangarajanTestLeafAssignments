package week3.day2assignments_03122024;

public class ExecutionClassElements extends Button {

	public static void main(String[] args) {
		ExecutionClassElements object = new ExecutionClassElements();
		//WebElement and Button Class
		object.click();
		object.setText();
		object.submit();
		
		//RadioButton Class
		RadioButton rb = new RadioButton();
		rb.click();
		rb.setText();
		rb.selectRadioButton();
		rb.submit();
		
		// CheckboxButton Class();
		
		CheckBoxButton cb = new CheckBoxButton();
		cb.click();
		cb.setText();
		cb.submit();
		cb.clickCheckButton();
		
		// TextField Class
		
		TextField tf = new TextField();
		tf.click();
		tf.setText();
		tf.getText();
		
		
		

	}

}
