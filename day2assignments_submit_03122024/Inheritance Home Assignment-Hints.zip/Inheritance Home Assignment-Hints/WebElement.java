package week3.day2assignments_03122024;

public class WebElement {
	public void click() {
		System.out.println("Click on a page");

	}
	public void setText() {
		System.out.println("To set a Text page");

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
