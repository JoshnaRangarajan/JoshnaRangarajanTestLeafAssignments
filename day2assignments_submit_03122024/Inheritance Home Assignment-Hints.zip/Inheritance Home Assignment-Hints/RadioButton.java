package week3.day2assignments_03122024;

public class RadioButton extends Button {
	public void selectRadioButton() {
		System.out.println("Selection of Radio Button");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
